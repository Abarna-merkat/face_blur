# Real-Time-Face-Blur-using-OpenCV-Python-APPARKY

> In this Project we'll make a blur Faces on Live Camera by using OpenCV Python
> 
>




-------------------
> 
> To get more interesting projects follow our GitHub page at [Here](https://github.com/Apparky)
> 
> To get more interesting projects follow our Bitbucket page at [Here](https://bitbucket.org/apparky-web/workspace/overview)
> 
> To know more about [__APPARKY__](https://apparky.vercel.app/) Click [Here](https://apparky-soumenmtec-gmailcom.vercel.app/)





